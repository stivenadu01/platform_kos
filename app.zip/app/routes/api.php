<?php

// Auth
// Session user
get('/api/auth/me', 'ApiAuthController@me', ['auth']);
// Login & Register
post('/api/auth/login', 'ApiAuthController@login');
post('/api/auth/register', 'ApiAuthController@register');
get('/api/auth/google/start', 'ApiAuthController@googleStart');
get('/api/auth/google/callback', 'ApiAuthController@googleCallback');
post('/api/auth/google/complete', 'ApiAuthController@googleComplete');
// Logout
post('/api/auth/logout', 'ApiAuthController@logout', ['auth']);
post('/api/auth/logout-all', 'ApiAuthController@logoutAllDevices', ['auth']);
post('/api/auth/profile', 'ApiAuthController@updateProfile', ['auth']);
post('/api/auth/profile/foto', 'ApiAuthController@uploadFotoProfil', ['auth']);
post('/api/auth/password', 'ApiAuthController@changePassword', ['auth']);

// Password Reset
post('/api/auth/request-reset', 'ApiAuthController@requestReset');
post('/api/auth/reset-password', 'ApiAuthController@resetPassword');

post('/api/payment/midtrans/notification', 'ApiLanggananController@midtransNotification');
get('/api/langganan/pembayaran/{id}/bukti', 'ApiLanggananController@buktiPembayaran', ['auth', 'role:admin,pemilik']);


get('/api/fasilitas', 'ApiFasilitasController@index');
get('/api/aturan', 'ApiAturanController@publicIndex');
get('/api/lokasi/search', 'ApiLokasiController@search');
get('/api/lokasi/referensi', 'ApiLokasiReferensiController@publicIndex');

// =====================================================
// PEMILIK - KOS
// =====================================================
get('/api/pemilik/kos', 'ApiKosController@index', ['auth', 'role:pemilik']);
get('/api/pemilik/kos/fasilitas', 'ApiKosController@fasilitas', ['auth', 'role:pemilik']);
get('/api/pemilik/kos/aturan', 'ApiAturanController@ownerList', ['auth', 'role:pemilik']);
get('/api/pemilik/kos/aturan/by-kos', 'ApiAturanController@ownerByKos', ['auth', 'role:pemilik']);
post('/api/pemilik/kos/resolve-google-maps', 'ApiKosController@resolveGoogleMapsLink', ['auth', 'role:pemilik']);
get('/api/pemilik/kos/{id}', 'ApiKosController@show', ['auth', 'role:pemilik']);
post('/api/pemilik/kos', 'ApiKosController@store', ['auth', 'role:pemilik']);
put('/api/pemilik/kos/{id}', 'ApiKosController@update', ['auth', 'role:pemilik']);
delete('/api/pemilik/kos/{id}', 'ApiKosController@destroy', ['auth', 'role:pemilik']);

// dashboard
get('/api/pemilik/dashboard', 'ApiDashboardController@index', ['auth', 'role:pemilik']);
get('/api/pemilik/onboarding', 'ApiOnboardingController@status', ['auth', 'role:pemilik']);

// =========================================================
// FOTO KOS - PEMILIK
// =========================================================
get('/api/pemilik/kos/foto/{id_kos}', 'ApiFotoController@index', ['auth', 'role:pemilik']);
post('/api/pemilik/kos/foto/{id_kos}', 'ApiFotoController@store', ['auth', 'role:pemilik']);
put('/api/pemilik/kos/foto/{id_kos}/{id_foto}/thumbnail', 'ApiFotoController@thumbnail', ['auth', 'role:pemilik']);
delete('/api/pemilik/kos/foto/{id_kos}/{id_foto}', 'ApiFotoController@destroy', ['auth', 'role:pemilik']);

// =========================================================
// PENGHUNI - PEMILIK
// =========================================================
get('/api/pemilik/penghuni', 'ApiPenghuniController@index', ['auth', 'role:pemilik','pro']);
get('/api/pemilik/penghuni/kamar', 'ApiPenghuniController@kamar', ['auth', 'role:pemilik','pro']);
get('/api/pemilik/penghuni/user-by-nik', 'ApiPenghuniController@userByNik', ['auth', 'role:pemilik','pro']);
get('/api/pemilik/penghuni/show', 'ApiPenghuniController@show', ['auth', 'role:pemilik','pro']);
post('/api/pemilik/penghuni', 'ApiPenghuniController@store', ['auth', 'role:pemilik','pro']);
put('/api/pemilik/penghuni', 'ApiPenghuniController@update', ['auth', 'role:pemilik','pro']);
post('/api/pemilik/penghuni/update', 'ApiPenghuniController@update', ['auth', 'role:pemilik','pro']);
put('/api/pemilik/penghuni/keluar', 'ApiPenghuniController@keluar', ['auth', 'role:pemilik','pro']);
delete('/api/pemilik/penghuni', 'ApiPenghuniController@destroy', ['auth', 'role:pemilik','pro']);

// =========================================================
// KAMAR - PEMILIK
// =========================================================
get('/api/pemilik/tipe-kamar', 'ApiTipeKamarController@index', ['auth', 'role:pemilik']);
get('/api/pemilik/tipe-kamar/show', 'ApiTipeKamarController@show', ['auth', 'role:pemilik']);
post('/api/pemilik/tipe-kamar', 'ApiTipeKamarController@store', ['auth', 'role:pemilik']);
put('/api/pemilik/tipe-kamar', 'ApiTipeKamarController@update', ['auth', 'role:pemilik']);
delete('/api/pemilik/tipe-kamar', 'ApiTipeKamarController@destroy', ['auth', 'role:pemilik']);
get('/api/pemilik/tipe-kamar/harga', 'ApiTipeKamarController@harga', ['auth', 'role:pemilik']);
put('/api/pemilik/tipe-kamar/harga', 'ApiTipeKamarController@simpanHarga', ['auth', 'role:pemilik']);
get('/api/pemilik/tipe-kamar/fasilitas', 'ApiTipeKamarController@fasilitas', ['auth', 'role:pemilik']);
put('/api/pemilik/tipe-kamar/fasilitas', 'ApiTipeKamarController@simpanFasilitas', ['auth', 'role:pemilik']);
get('/api/pemilik/tipe-kamar/foto', 'ApiTipeKamarController@foto', ['auth', 'role:pemilik']);
post('/api/pemilik/tipe-kamar/{id_tipe_kamar}/foto', 'ApiTipeKamarController@tambahFoto', ['auth', 'role:pemilik']);
put('/api/pemilik/tipe-kamar/foto/{id_foto}/thumbnail', 'ApiTipeKamarController@thumbnail', ['auth', 'role:pemilik']);
delete('/api/pemilik/tipe-kamar/foto/{id_foto}', 'ApiTipeKamarController@hapusFoto', ['auth', 'role:pemilik']);
get('/api/pemilik/kamar', 'ApiKamarController@index', ['auth', 'role:pemilik']);
get('/api/pemilik/kamar/show', 'ApiKamarController@show', ['auth', 'role:pemilik']);
get('/api/pemilik/kamar/harga', 'ApiKamarController@harga', ['auth', 'role:pemilik']);
get('/api/pemilik/kamar/kos', 'ApiKamarController@kos', ['auth', 'role:pemilik']);
post('/api/pemilik/kamar', 'ApiKamarController@store', ['auth', 'role:pemilik']);
post('/api/pemilik/kamar/bulk', 'ApiKamarController@bulk', ['auth', 'role:pemilik']);
put('/api/pemilik/kamar', 'ApiKamarController@update', ['auth', 'role:pemilik']);
put('/api/pemilik/kamar/harga', 'ApiKamarController@simpanHarga', ['auth', 'role:pemilik']);
delete('/api/pemilik/kamar', 'ApiKamarController@destroy', ['auth', 'role:pemilik']);
put('/api/pemilik/kamar/status', 'ApiKamarController@status', ['auth', 'role:pemilik']);

// =========================================================
// TAGIHAN & PEMBAYARAN - PEMILIK
// =========================================================
get('/api/pemilik/langganan', 'ApiLanggananController@index', ['auth', 'role:pemilik']);
get('/api/pemilik/langganan/checkout', 'ApiLanggananController@checkoutInfo', ['auth', 'role:pemilik']);
get('/api/pemilik/langganan/pembayaran', 'ApiLanggananController@pembayaran', ['auth', 'role:pemilik']);
get('/api/pemilik/langganan/pembayaran/{id}/midtrans-status', 'ApiLanggananController@midtransStatus', ['auth', 'role:pemilik']);
get('/api/pemilik/langganan/pembayaran/{id}', 'ApiLanggananController@pembayaranShow', ['auth', 'role:pemilik']);
post('/api/pemilik/langganan/pembayaran', 'ApiLanggananController@buatPembayaran', ['auth', 'role:pemilik']);
post('/api/pemilik/langganan/pembayaran/bukti', 'ApiLanggananController@uploadBukti', ['auth', 'role:pemilik']);
get('/api/pemilik/langganan/riwayat', 'ApiLanggananController@history', ['auth', 'role:pemilik']);

get('/api/pemilik/tagihan', 'ApiTagihanController@index', ['auth', 'role:pemilik','pro']);
get('/api/pemilik/tagihan/show', 'ApiTagihanController@show', ['auth', 'role:pemilik','pro']);
post('/api/pemilik/tagihan/penyesuaian', 'ApiTagihanController@adjustment', ['auth', 'role:pemilik','pro']);
post('/api/pemilik/tagihan/pembayaran', 'ApiTagihanController@payment', ['auth', 'role:pemilik','pro']);



// =========================================================
// USER - LOKASI & PENCARIAN KOS
// =========================================================
get('/api/kos/search', 'ApiKosSearchController@index');
get('/api/kos/{id}/favorit', 'ApiKosSearchController@favoriteStatus', ['auth', 'role:pelanggan']);
get('/api/kos/{id}', 'ApiKosSearchController@show');
get('/api/pelanggan/favorit', 'ApiKosSearchController@favoriteList', ['auth', 'role:pelanggan']);
post('/api/pelanggan/favorit', 'ApiKosSearchController@toggleFavorite', ['auth', 'role:pelanggan']);

// =========================================================
// ADMIN - DASHBOARD
// =========================================================
get('/api/admin/dashboard', 'ApiAdminController@dashboard', ['auth', 'role:admin']);

// ADMIN - DATA MASTER
get('/api/admin/fasilitas', 'ApiFasilitasAdminController@index', ['auth', 'role:admin']);
get('/api/admin/fasilitas/{id}', 'ApiFasilitasAdminController@show', ['auth', 'role:admin']);
post('/api/admin/fasilitas', 'ApiFasilitasAdminController@store', ['auth', 'role:admin']);
put('/api/admin/fasilitas/{id}', 'ApiFasilitasAdminController@update', ['auth', 'role:admin']);
delete('/api/admin/fasilitas/{id}', 'ApiFasilitasAdminController@delete', ['auth', 'role:admin']);
get('/api/admin/aturan', 'ApiAturanController@adminIndex', ['auth', 'role:admin']);
get('/api/admin/aturan/{id}', 'ApiAturanController@adminShow', ['auth', 'role:admin']);
post('/api/admin/aturan', 'ApiAturanController@adminStore', ['auth', 'role:admin']);
put('/api/admin/aturan/{id}', 'ApiAturanController@adminUpdate', ['auth', 'role:admin']);
delete('/api/admin/aturan/{id}', 'ApiAturanController@adminDelete', ['auth', 'role:admin']);
get('/api/admin/lokasi', 'ApiLokasiReferensiController@index', ['auth', 'role:admin']);
post('/api/admin/lokasi/resolve-google-maps', 'ApiLokasiReferensiController@resolveGoogleMapsLink', ['auth', 'role:admin']);
get('/api/admin/lokasi/{id}', 'ApiLokasiReferensiController@show', ['auth', 'role:admin']);
post('/api/admin/lokasi', 'ApiLokasiReferensiController@store', ['auth', 'role:admin']);
put('/api/admin/lokasi/{id}', 'ApiLokasiReferensiController@update', ['auth', 'role:admin']);
delete('/api/admin/lokasi/{id}', 'ApiLokasiReferensiController@destroy', ['auth', 'role:admin']);



// ADMIN - MANAJEMEN PENGGUNA
get('/api/admin/pengguna', 'ApiAdminController@userList', ['auth', 'role:admin']);
post('/api/admin/pengguna', 'ApiAdminController@userCreate', ['auth', 'role:admin']);
post('/api/admin/pengguna/verifikasi', 'ApiAdminController@userVerify', ['auth', 'role:admin']);
post('/api/admin/pengguna/status', 'ApiAdminController@userStatus', ['auth', 'role:admin']);

// ADMIN - VERIFIKASI KOS
// =========================================================
get('/api/admin/verifikasi', 'ApiAdminController@verificationList', ['auth', 'role:admin']);
get('/api/admin/verifikasi/{id}', 'ApiAdminController@verificationShow', ['auth', 'role:admin']);
post('/api/admin/verifikasi/keputusan', 'ApiAdminController@verificationDecision', ['auth', 'role:admin']);
post('/api/pemilik/kos/ajukan-verifikasi', 'ApiAdminController@submitVerification', ['auth', 'role:pemilik']);

// =========================================================
// PELANGGAN - LAPORAN KOS
// =========================================================
get('/api/pelanggan/riwayat-kos', 'ApiClaimController@history', ['auth', 'role:pelanggan']);
get('/api/pelanggan/tagihan', 'ApiClaimController@bills', ['auth', 'role:pelanggan']);
get('/api/pelanggan/tagihan/show', 'ApiClaimController@billShow', ['auth', 'role:pelanggan']);
get('/api/pelanggan/claim/candidates', 'ApiClaimController@candidates', ['auth', 'role:pelanggan']);
get('/api/pelanggan/claim', 'ApiClaimController@mine', ['auth', 'role:pelanggan']);
post('/api/pelanggan/claim', 'ApiClaimController@store', ['auth', 'role:pelanggan']);
get('/api/pemilik/claim', 'ApiClaimController@ownerIndex', ['auth', 'role:pemilik']);
post('/api/pemilik/claim/keputusan', 'ApiClaimController@decision', ['auth', 'role:pemilik']);

post('/api/laporan/kos', 'ApiLaporanController@store', ['auth', 'role:pelanggan']);
get('/api/laporan/kos/saya', 'ApiLaporanController@mine', ['auth', 'role:pelanggan']);

// =========================================================
// ADMIN - LAPORAN KOS
// =========================================================
get('/api/admin/langganan', 'ApiAdminController@subscriptions', ['auth', 'role:admin']);
get('/api/admin/langganan/metode-pembayaran', 'ApiAdminController@paymentMethods', ['auth', 'role:admin']);
get('/api/admin/langganan/metode-pembayaran/ringkasan', 'ApiAdminController@paymentMethodSummary', ['auth', 'role:admin']);
post('/api/admin/langganan/metode-pembayaran', 'ApiAdminController@paymentMethodSave', ['auth', 'role:admin']);
post('/api/admin/langganan/metode-pembayaran/status', 'ApiAdminController@paymentMethodStatus', ['auth', 'role:admin']);
// Route statis harus didaftarkan sebelum route parameter agar /pembayaran tidak dianggap sebagai {id}.
get('/api/admin/langganan/pembayaran', 'ApiAdminController@subscriptionPayments', ['auth', 'role:admin']);
get('/api/admin/langganan/pembayaran/{id}', 'ApiAdminController@subscriptionPaymentShow', ['auth', 'role:admin']);
post('/api/admin/langganan/pembayaran/keputusan', 'ApiAdminController@subscriptionPaymentDecision', ['auth', 'role:admin']);
get('/api/admin/langganan/{id}', 'ApiAdminController@subscriptionShow', ['auth', 'role:admin']);

get('/api/admin/laporan', 'ApiAdminLaporanController@index', ['auth', 'role:admin']);
get('/api/admin/laporan/{id}', 'ApiAdminLaporanController@show', ['auth', 'role:admin']);
post('/api/admin/laporan/keputusan', 'ApiAdminLaporanController@decision', ['auth', 'role:admin']);
