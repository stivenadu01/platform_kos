<?php

get('/', 'UserController@home');

// AUTH
get('/login', 'AuthController@login');
get('/register', 'AuthController@register');
get('/verify', 'AuthController@verify');
get('/reset-password', 'AuthController@resetPassword');


// PEMILIK
get('/pemilik', 'PemilikController@dashboard', ['auth', 'role:pemilik']);
get('/pemilik/profil', 'PemilikController@profil', ['auth', 'role:pemilik']);
get('/pemilik/kos', 'PemilikController@kos', ['auth', 'role:pemilik']);
get('/pemilik/kos/tambah', 'PemilikController@tambahKos', ['auth', 'role:pemilik']);
get('/pemilik/kos/edit', 'PemilikController@editKos', ['auth', 'role:pemilik']);

get('/pemilik/kos/foto', 'PemilikController@fotoKos', ['auth', 'role:pemilik']);


get('/pemilik/pembayaran', 'PemilikController@pembayaran', ['auth', 'role:pemilik']);


// Kelola penghuni
get('/pemilik/penghuni', 'PemilikController@penghuni', ['auth', 'role:pemilik']);
get('/pemilik/penghuni/tambah', 'PemilikController@tambahPenghuni', ['auth', 'role:pemilik']);
get('/pemilik/penghuni/edit', 'PemilikController@editPenghuni', ['auth', 'role:pemilik']);

// Kelola kamar
get('/pemilik/kamar', 'PemilikController@kamar', ['auth', 'role:pemilik']);
get('/pemilik/kamar/tambah', 'PemilikController@tambahKamar', ['auth', 'role:pemilik']);
get('/pemilik/kamar/edit', 'PemilikController@editKamar', ['auth', 'role:pemilik']);

// USER FLOW (placeholder routes — implementation dilanjutkan pada fase berikutnya)
get('/cari-kos', 'UserController@search');
get('/kos/{id}', 'UserController@detailKos');
get('/user/favorit', 'UserController@favorit', ['auth', 'role:pelanggan']);
get('/user/profil', 'UserController@profil', ['auth', 'role:pelanggan']);
get('/user/laporan', 'UserController@laporan', ['auth', 'role:pelanggan']);

// ADMIN
get('/admin', 'AdminController@dashboard', ['auth', 'role:admin']);
get('/admin/pengguna', 'AdminController@pengguna', ['auth', 'role:admin']);
get('/admin/verifikasi', 'AdminController@verifikasi', ['auth', 'role:admin']);
get('/admin/laporan', 'AdminController@laporan', ['auth', 'role:admin']);
