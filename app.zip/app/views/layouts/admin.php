<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($title ?? 'Admin BetaKos') ?></title>
  <link rel="icon" type="image/x-icon" href="<?= BASE_URL ?>/assets/icon/favicon.ico">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/app.css">
  <script>
    window.BASE_URL = <?= json_encode(BASE_URL) ?>;
    window.NOMOR_WA = <?= json_encode($_ENV['NOMOR_WA'] ?? '') ?>;
    window.__USER__ = <?= json_encode($_SESSION['user'] ?? null, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    window.__CSRF_TOKEN__ = <?= json_encode(csrf_token()) ?>;
  </script>
  <script src="<?= BASE_URL ?>/assets/js/api.js"></script>
  <script src="<?= BASE_URL ?>/assets/js/store.js"></script>
  <script src="<?= BASE_URL ?>/assets/js/utils.js"></script>
  <script src="<?= BASE_URL ?>/assets/js/app.js"></script>
  <script defer src="https://unpkg.com/alpinejs"></script>
</head>
<body class="bg-slate-50 text-slate-800">
  <div x-data="{ sidebarOpen: false }" class="min-h-screen">
    <div x-show="sidebarOpen" x-cloak @click="sidebarOpen = false" class="fixed inset-0 bg-black/40 z-40 lg:hidden"></div>
    <?php include ROOT_PATH . '/app/views/partials/admin/sidebar.php'; ?>
    <div class="lg:ml-64 min-h-screen min-w-0 overflow-x-hidden">
      <?php include ROOT_PATH . '/app/views/partials/admin/topbar.php'; ?>
      <main class="p-4 sm:p-6 lg:p-8 min-w-0 overflow-x-hidden">
        <?= $content ?>
      </main>
    </div>
    <?php include ROOT_PATH . '/app/views/partials/toast.php'; ?>
  </div>
</body>
</html>
