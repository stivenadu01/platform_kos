-- BetaKos: simpan Google Place ID secara opsional.
-- Jalankan sekali pada database platform_kos.
ALTER TABLE kos
    ADD COLUMN google_place_id VARCHAR(255) NULL AFTER longitude,
    ADD INDEX idx_kos_google_place_id (google_place_id);
